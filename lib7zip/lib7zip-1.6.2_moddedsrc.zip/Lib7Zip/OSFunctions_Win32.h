#ifndef __OS_FUNCTIONS_WIN32_H__
#define __OS_FUNCTIONS_WIN32_H__


#endif // __OS_FUNCTIONS_WIN32_H__
